package com.example.assignment1;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class HeartRate {
    public TextureView textureView;
    private String cameraId;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraCaptureSessions;
    private CaptureRequest.Builder captureRequestBuilder;
    private Size imageDimension;
    public static final int REQUEST_CAMERA_PERMISSION = 1;
    public boolean flash_state;
    public float ratebpm;
    private int mCurrentRollingAverage;
    private int mLastRollingAverage;
    private int mLastLastRollingAverage;
    private ArrayList<Long> mTimeArray;
    private int numCaptures;
    private int mNumIter;
    private long start_timer;
    public TextView result;
    private MainActivity activity;

    public HeartRate(MainActivity act, TextView text, TextureView cam) {
        result = text;
        textureView = cam;
        assert textureView != null;
        textureView.setSurfaceTextureListener(textureListener);
        flash_state = false;
        activity = act;
    }

    private void refreshRate() {
        mTimeArray = new ArrayList<Long>();
        numCaptures = 0;
        mNumIter = 0;
        mLastRollingAverage = 0;
    }

    public void start() {
        captureRequestBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
        flash_state = true;
        refreshRate();
        updatePreview();
        result.setText("Calculating Heart Rate...");
    }

    private void stop() {
        captureRequestBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
        updatePreview();
        flash_state = false;
        calcBPM();
    }

    private void calcBPM() {
        long med;
        ArrayList<Long> timedist = new ArrayList<Long>();
        for (int i = 0; i < mTimeArray.size()-1; i++) {
            timedist.add(mTimeArray.get(i+1) - mTimeArray.get(i));
        }
        Collections.sort(timedist);
        med = (long) timedist.get(timedist.size()/2);
        ratebpm = (float) (60000.0/med);
        result.setText("Rate = "+ratebpm+" BPM");
    }

    private void createCameraPreview() {
        try {
            SurfaceTexture texture = textureView.getSurfaceTexture();
            assert texture != null;
            texture.setDefaultBufferSize(imageDimension.getWidth(), imageDimension.getHeight());
            Surface surface = new Surface(texture);
            captureRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            captureRequestBuilder.addTarget(surface);
            cameraDevice.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    if (null == cameraDevice) {
                        return;
                    }
                    cameraCaptureSessions = cameraCaptureSession;
                    updatePreview();
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                    Toast.makeText(activity, "Configuration change", Toast.LENGTH_SHORT).show();
                }
            }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void openCamera() {
        CameraManager manager = (CameraManager) activity.getSystemService(Context.CAMERA_SERVICE);
        try {
            cameraId = manager.getCameraIdList()[0];
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            assert map != null;
            imageDimension = map.getOutputSizes(SurfaceTexture.class)[0];
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
                return;
            }
            manager.openCamera(cameraId, stateCallback, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void updatePreview() {
        captureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
        try {
            cameraCaptureSessions.setRepeatingRequest(captureRequestBuilder.build(), null, activity.mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void closeCamera() {
        if (null != cameraDevice) {
            cameraDevice.close();
            cameraDevice = null;
        }
    }

    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            cameraDevice = camera;
            createCameraPreview();
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
            cameraDevice.close();
        }

        @Override
        public void onError(CameraDevice camera, int error) {
            if (cameraDevice != null)
                cameraDevice.close();
            cameraDevice = null;
        }
    };

    TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            openCamera();
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
            if (flash_state == true) {
                Bitmap bmp = textureView.getBitmap();
                int width = bmp.getWidth();
                int height = bmp.getHeight();
                int[] pixels = new int[height * width];
                // Get pixels from the bitmap, starting at (x,y) = (width/2,height/2)
                // and totaling width/20 rows and height/20 columns
                bmp.getPixels(pixels, 0, width, width / 2, height / 2, width / 20, height / 20);
                int sum = 0;
                for (int i = 0; i < height * width; i++) {
                    int red = (pixels[i] >> 16) & 0xFF;
                    sum = sum + red;
                }

                if (numCaptures == 0) {
                    start_timer = System.currentTimeMillis();
                }
                // Waits 20 captures, to remove startup artifacts.  First average is the sum.
                else if (numCaptures == 20) {
                    mCurrentRollingAverage = sum;
                }
                // Next 18 averages needs to incorporate the sum with the correct N multiplier
                // in rolling average.
                else if (numCaptures > 20 && numCaptures < 49) {
                    mCurrentRollingAverage = (mCurrentRollingAverage*(numCaptures-20) + sum)/(numCaptures - 19);
                }
                // From 49 on, the rolling average incorporates the last 30 rolling averages.
                else if (numCaptures >= 49) {
                    mCurrentRollingAverage = (mCurrentRollingAverage*29 + sum)/30;
                    if (mLastRollingAverage > mCurrentRollingAverage && mLastRollingAverage > mLastLastRollingAverage && System.currentTimeMillis() - start_timer <= 45000) {
                        mTimeArray.add(System.currentTimeMillis());
                        result.setText((45 - (System.currentTimeMillis() - start_timer)/1000) + "s remaining");
                        mNumIter++;
                    }
                    else if (mTimeArray.size() != 0) {
                        if (System.currentTimeMillis() - start_timer > 45000) {
                            stop();
                        }
                    }
                }

                numCaptures++;
                mLastLastRollingAverage = mLastRollingAverage;
                mLastRollingAverage = mCurrentRollingAverage;
            }
        }
    };
}
