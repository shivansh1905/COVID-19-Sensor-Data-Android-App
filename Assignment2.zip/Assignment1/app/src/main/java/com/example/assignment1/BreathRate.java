package com.example.assignment1;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.IBinder;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;

public class BreathRate {
    public static long start_timer;
    private static ArrayList<Float> accelValuesZ;
    public static TextView result;
    private MainActivity activity;
    public static float ratebpm;
    private static ArrayList<Long> mTimeArray;
    private static int numCaptures;

    public BreathRate(MainActivity act, TextView text) {
        result = text;
        activity = act;
    }

    public void start() {
        Intent startSenseService = new Intent(activity, Accelerometer.class);
        activity.startService(startSenseService);
        result.setText("Calculating Breath Rate...");
    }

    private static void calcBPM() {
        long med;
        for (int i=0; i<3; i++) {
            mTimeArray.remove(0);
        }
        ArrayList<Long> timedist = new ArrayList<Long>();
        for (int i=0; i<mTimeArray.size()-2; i+=2) {
            timedist.add(mTimeArray.get(i+2) - mTimeArray.get(i));
        }
        Collections.sort(timedist);
        med = timedist.get(timedist.size()-1);
        ratebpm = (float) (60000.0/med);
        result.setText("Rate = "+ratebpm+" BPM");
    }

    public static class Accelerometer extends Service implements SensorEventListener {
        private SensorManager accelManage;
        private Sensor senseAccel;

        @Override
        public void onCreate() {
            accelManage = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            senseAccel = accelManage.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        }

        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {
            accelManage.registerListener(this, senseAccel, SensorManager.SENSOR_DELAY_NORMAL);
            start_timer = System.currentTimeMillis();
            accelValuesZ = new ArrayList<Float>();
            mTimeArray = new ArrayList<Long>();
            numCaptures = 0;
            return START_NOT_STICKY;
        }

        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (System.currentTimeMillis() - start_timer <= 45000) {
                Sensor mySensor = sensorEvent.sensor;
                if (mySensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION) {
                    if (numCaptures == 0 || Math.signum(sensorEvent.values[2]) != Math.signum(accelValuesZ.get(numCaptures - 1))) {
                        accelValuesZ.add(sensorEvent.values[2]);
                        mTimeArray.add(System.currentTimeMillis());
                        numCaptures++;
                    }
                    result.setText((45 - (System.currentTimeMillis() - start_timer) / 1000) + "s remaining");
                }
            }
            else {
                accelManage.unregisterListener(this);
                if (start_timer != 0) {
                    calcBPM();
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    }
}
