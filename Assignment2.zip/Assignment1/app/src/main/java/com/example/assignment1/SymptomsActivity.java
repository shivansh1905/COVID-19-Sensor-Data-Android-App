package com.example.assignment1;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.location.LocationListener;
import android.location.LocationManager;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import static android.location.LocationManager.GPS_PROVIDER;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SymptomsActivity extends AppCompatActivity implements LocationListener {
    private SQLiteDatabase db;
    private LocationManager locationManager;
    public static final int REQUEST_LOCATION_PERMISSION = 1;
    private Location location;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        Bundle b = getIntent().getExtras();
        final float[] measurements = b.getFloatArray("measurements");
        final RatingBar ratings[] = new RatingBar[10];
        ratings[0] = (RatingBar) findViewById(R.id.nausea_stars);
        ratings[1] = (RatingBar) findViewById(R.id.headache_stars);
        ratings[2] = (RatingBar) findViewById(R.id.diarrhea_stars);
        ratings[3] = (RatingBar) findViewById(R.id.throat_stars);
        ratings[4] = (RatingBar) findViewById(R.id.fever_stars);
        ratings[5] = (RatingBar) findViewById(R.id.muscle_stars);
        ratings[6] = (RatingBar) findViewById(R.id.loss_stars);
        ratings[7] = (RatingBar) findViewById(R.id.cough_stars);
        ratings[8] = (RatingBar) findViewById(R.id.breath_stars);
        ratings[9] = (RatingBar) findViewById(R.id.tired_stars);
        Button upload_symptoms = (Button) findViewById(R.id.upload_symptoms);
        upload_symptoms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (locationManager.isProviderEnabled(GPS_PROVIDER) == true) {
                    if (ActivityCompat.checkSelfPermission(SymptomsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(SymptomsActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        ActivityCompat.requestPermissions(SymptomsActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
                        return;
                    }
                    while (location == null) {
                        locationManager.requestLocationUpdates(GPS_PROVIDER, 0, 0, SymptomsActivity.this);
                        location = locationManager.getLastKnownLocation(GPS_PROVIDER);
                    }

                    String query = "insert into covid(heart_rate, breath_rate, nausea, headache, diarrhea, throat, fever, muscle, loss, cough, breath, tired, longitude, latitude) values(" + measurements[0] + "," + measurements[1] + ",";
                    String temp = "";
                    for (int i = 0; i < 10; i++) {
                        int rating = (int) ratings[i].getRating();
                        temp += rating;
                        if (i != 9) {
                            temp += ",";
                        }
                    }
                    query += temp + "," + location.getLongitude() + "," + location.getLatitude() + ");";
                    JSONArray resultSet = new JSONArray();
                    try {
                        db = SQLiteDatabase.openOrCreateDatabase(getFilesDir() + "/Mittal.db", null);
                        db.beginTransaction();
                        try {
                            db.execSQL(query);
                            Cursor cursor = db.rawQuery("SELECT * FROM covid ", null);
                            if (cursor.moveToFirst()){
                                do {
                                    int totalColumn = cursor.getColumnCount();
                                    JSONObject rowObject = new JSONObject();
                                    for( int i=0 ;  i< totalColumn ; i++ )
                                    {
                                        if( cursor.getColumnName(i) != null )
                                        {
                                            try
                                            {
                                                if( cursor.getString(i) != null )
                                                {
                                                    rowObject.put(cursor.getColumnName(i) ,  cursor.getString(i) );
                                                }
                                                else
                                                {
                                                    rowObject.put( cursor.getColumnName(i) ,  "" );
                                                }
                                            }
                                            catch( Exception e )
                                            {
                                                Log.d("TAG_NAME", e.getMessage());
                                            }
                                        }
                                    }
                                    resultSet.put(rowObject);
                                    // Do something Here with values
                                } while(cursor.moveToNext());
                            }
                            cursor.close();
                            db.setTransactionSuccessful();
                        } catch (SQLiteException e) {
                            Toast.makeText(SymptomsActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        } finally {
                            db.endTransaction();
                        }
                    } catch (SQLException e) {
                        Toast.makeText(SymptomsActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                    try {
                        upload(resultSet);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    download();
                    Intent intent = new Intent(SymptomsActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(SymptomsActivity.this, "Please turn on location service", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onLocationChanged(Location location) {
        this.location = location;
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(SymptomsActivity.this, "Permission not granted", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void upload(JSONArray resultSet) throws IOException {
        String url = "http://192.168.0.150:5000/upload";
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        try {
            RequestBody requestBody = RequestBody.create(JSON, String.valueOf(resultSet));
            Request request = new Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build();
            OkHttpClient client = new OkHttpClient();
            client.newCall(request).enqueue(new Callback() {

                @Override
                public void onFailure(final Call call, final IOException e) {
                    // Handle the error
                }

                @Override
                public void onResponse(final Call call, final Response response) throws IOException {
                    if (!response.isSuccessful()) {
                        // Handle the error
                    }
                    // Upload successful
                }
            });

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void download() {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://192.168.0.150:5000/graph?subject_id=1&date=20110614")
                    .build();
            client.newCall(request).enqueue(new Callback() {

                @Override
                public void onFailure(final Call call, final IOException e) {
                    // Handle the error
                }

                @Override
                public void onResponse(final Call call, final Response response) throws IOException {
                    if (!response.isSuccessful()) {
                        // Handle the error
                    }
                    String jsonData = response.body().string();
                    int permission = ActivityCompat.checkSelfPermission(SymptomsActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    if (permission != PackageManager.PERMISSION_GRANTED) {
                        // We don't have permission so prompt the user
                        ActivityCompat.requestPermissions(SymptomsActivity.this, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
                    }
                    try{
                        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"matrix.json");
                        FileWriter writer = new FileWriter(file);
                        writer.append(jsonData);
                        writer.flush();
                        writer.close();
                    }
                    catch(Exception e){
                        e.getMessage();
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}