package com.example.assignment1;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;

public class MainActivity extends AppCompatActivity {

    public Handler mBackgroundHandler;
    private HandlerThread mBackgroundThread;
    private HeartRate hr;
    private BreathRate br;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button heart_rate = findViewById(R.id.heart_rate_button);
        hr = new HeartRate(MainActivity.this, (TextView) findViewById(R.id.heart_rate_text), (TextureView) findViewById(R.id.textureView));
        heart_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hr.start();
            }
        });

        Button respiratory_rate = findViewById(R.id.respiratory_rate_button);
        br = new BreathRate(MainActivity.this, (TextView) findViewById(R.id.respiratory_rate_text));
        respiratory_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                br.start();
            }
        });

        Button upload_signs = findViewById(R.id.upload_signs);
        upload_signs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (hr.ratebpm != 0.0 && BreathRate.ratebpm != 0.0) {
                    try {
                        db = SQLiteDatabase.openOrCreateDatabase(getFilesDir()+"/Mittal.db", null);
                        db.beginTransaction();
                        try {
                            db.execSQL("create table if not exists covid (heart_rate real, breath_rate real, nausea integer, headache integer, diarrhea integer, throat integer, fever integer, muscle integer, loss integer, cough integer, breath integer, tired integer, longitude real, latitude real);");
                            db.setTransactionSuccessful();
                        }
                        catch (SQLiteException e) {
                            Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                        finally {
                            db.endTransaction();
                        }
                        Intent intent = new Intent(MainActivity.this, SymptomsActivity.class);
                        float measurements[] = new float[2];
                        measurements[0] = hr.ratebpm;
                        measurements[1] = BreathRate.ratebpm;
                        intent.putExtra("measurements", measurements);
                        startActivity(intent);
                    }
                    catch (SQLException e){
                        Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
                else {
                    Toast.makeText(MainActivity.this, "Please complete the measurements", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    // onResume
    protected void startBackgroundThread() {
        mBackgroundThread = new HandlerThread("Camera Background");
        mBackgroundThread.start();
        mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
    }

    // onPause
    protected void stopBackgroundThread() {
        mBackgroundThread.quitSafely();
        try {
            mBackgroundThread.join();
            mBackgroundThread = null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        startBackgroundThread();
        if (hr.textureView.isAvailable()) {
            hr.openCamera();}
        /*if (hr.textureView.isAvailable()) {
            hr.openCamera();
        } else {
            hr.textureView.setSurfaceTextureListener(hr.textureListener);
        }*/
    }

    @Override
    protected void onPause() {
        hr.closeCamera();
        hr.flash_state = false;
        hr.result.setText("Click to Calculate Heart Rate");
        BreathRate.start_timer = 0;
        BreathRate.result.setText("Click to Calculate Respiratory Rate");
        stopBackgroundThread();
        super.onPause();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == hr.REQUEST_CAMERA_PERMISSION) {
            if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(MainActivity.this, "Permission not granted", Toast.LENGTH_LONG).show();
            }
        }
    }

}